<div class="panel-body">


	<?php echo csrf_token(); ?>

	<div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
		<?php echo Form::label('name', trans('student.name'), ['class' => 'col-md-4 control-label']); ?>


		<div class="col-md-6">
			<?php echo Form::text('name', old('name') ? old('name') : @$student->name, ['class' => 'form-control', 'autofocus' => true]); ?>


			<?php if($errors->has('name')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('name')); ?></strong>
				</span>
			<?php endif; ?>
		</div>
	</div>

	<div class="form-group<?php echo e($errors->has('class') ? 'has-error' : ''); ?>">
		<?php echo Form::label('class', trans('student.class'), ['class' => 'col-md-4 control-label']); ?>


		<div class="col-md-6">
			<?php echo Form::text('class', old('class') ? old('class') : @$student->class, ['class' => 'form-control']); ?>


			<?php if($errors->has('class')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('class')); ?></strong>
				</span>
			<?php endif; ?>
		</div>
	</div>

	<div class="form-group<?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
		<?php echo Form::label('address', trans('student.address'), ['class' => 'col-md-4 control-label']); ?>


		<div class="col-md-6">
			<?php echo Form::textarea('address', old('address') ? old('address') : @$student->address, ['class' => 'form-control']); ?>


			<?php if($errors->has('address')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('address')); ?></strong>
				</span>
			<?php endif; ?>
		</div>
	</div>

	<div class="form-group<?php echo e($errors->has('phone_no') ? 'has-error' : ''); ?>">
		<?php echo Form::label('phone_no', trans('student.phone_no'), ['class' => 'col-md-4 control-label']); ?>


		<div class="col-md-6">
			<?php echo Form::number('phone_no', old('phone_no') ? old('phone_no') : @$student->phone_no, ['class' => 'form-control']); ?>


			<?php if($errors->has('phone_no')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('phone_no')); ?></strong>
				</span>
			<?php endif; ?>
		</div>
	</div>

	<div class="form-group<?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
		<?php echo Form::label('status', trans('student.status'), ['class' => 'col-md-4 control-label']); ?>


		<div class="col-md-6">
			<?php echo Form::select('status', ['1'=>'Active', '2'=>'Inactive'], old('status') ? old('status') : @$student->status, ['class' => 'form-control']); ?>


			<?php if($errors->has('status')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('status')); ?></strong>
				</span>
			<?php endif; ?>
		</div>
	</div>

	<div class = "form-group">
		<div class="col-sm-10 col-md-offset-2">
			<button type="submit" class="btn btn-primary"><i class="fa fa-btn fa-user">Save</i></button>
			<?php echo link_to_route('student.index', 'Cancel', null, array('class' => 'btn btn-danger')); ?>

		</div>
	</div>
</div>
@extentds('layouts.app')

<?php $__env->startSection('content'); ?>
<div class="containter">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					<?php echo trans('student.title'); ?>

				</div>
				<?php echo Form::open(array('route' => 'student.store', 'class' => 'form-horizontal')); ?>

				<?php echo $__env->make('student/_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
@enndsection


<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					<?php echo trans('student.title'); ?>

					<?php echo html_entity_decode(Html::link(route('student.create'), trans('student.add'))); ?>

				</div>
				<div class="panel-body"> 
					<table class="table table-striped table-bordered table-hover" id="view-organizations">
						<thead>
							<tr>
								<th> <?php echo trans('student.name'); ?> </th>
								<th> <?php echo trans('student.class'); ?> </th>
								<th> <?php echo trans('student.address'); ?> </th>
								<th> <?php echo trans('student.phone_no'); ?> </th>
								<th> <?php echo trans('student.status'); ?> </th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo Html::link(route('student.edit', $stud->id), $stud->name); ?></td>
								<td><?php echo $stud->class; ?></td>
								<td><?php echo $stud->address; ?></td>
								<td><?php echo $stud->phone_no; ?></td>
								<td><?php echo $stud->status; ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StudentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //$id = Request::segment(2);
        switch($this->method()) 
        {
            case 'GET':
            case 'DELETE':
                 return [
                            //
                        ];
            case 'POST':
                 return [
                            'name' => 'required|regex:/(^[A-Za-z0-9]+$)+/',
                            'class' => 'required|regex:/(^[A-Za-z0-9]+$)+/',
                            'phone_no' => 'required|regex:/(^[0-9]+$)+/|max:15',
                        ];
                break;
            case 'PUT':
            case 'PATCH':
                 return [
                            'name' => 'required|regex:/(^[A-Za-z0-9]+$)+/',
                            'class' => 'required|regex:/(^[A-Za-z0-9]+$)+/',
                            'phone_no' => 'required|regex:/(^[0-9]+$)+/|max:15',
                        ];
                break;
            default:
                break;
        }
    }
}

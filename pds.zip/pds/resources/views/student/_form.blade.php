<div class="panel-body">


	{!! csrf_token() !!}
	<div class="form-group{{ $errors->has('name') ? 'has-error' : '' }}">
		{!! Form::label('name', trans('student.name'), ['class' => 'col-md-4 control-label']) !!}

		<div class="col-md-6">
			{!! Form::text('name', old('name') ? old('name') : @$student->name, ['class' => 'form-control', 'autofocus' => true]) !!}

			@if($errors->has('name'))
				<span class="help-block">
					<strong>{{ $errors->first('name') }}</strong>
				</span>
			@endif
		</div>
	</div>

	<div class="form-group{{ $errors->has('class') ? 'has-error' : ''}}">
		{!! Form::label('class', trans('student.class'), ['class' => 'col-md-4 control-label']) !!}

		<div class="col-md-6">
			{!! Form::text('class', old('class') ? old('class') : @$student->class, ['class' => 'form-control']) !!}

			@if($errors->has('class'))
				<span class="help-block">
					<strong>{{ $errors->first('class') }}</strong>
				</span>
			@endif
		</div>
	</div>

	<div class="form-group{{ $errors->has('address') ? 'has-error' : ''}}">
		{!! Form::label('address', trans('student.address'), ['class' => 'col-md-4 control-label']) !!}

		<div class="col-md-6">
			{!! Form::textarea('address', old('address') ? old('address') : @$student->address, ['class' => 'form-control']) !!}

			@if($errors->has('address'))
				<span class="help-block">
					<strong>{{ $errors->first('address') }}</strong>
				</span>
			@endif
		</div>
	</div>

	<div class="form-group{{ $errors->has('phone_no') ? 'has-error' : ''}}">
		{!! Form::label('phone_no', trans('student.phone_no'), ['class' => 'col-md-4 control-label']) !!}

		<div class="col-md-6">
			{!! Form::number('phone_no', old('phone_no') ? old('phone_no') : @$student->phone_no, ['class' => 'form-control']) !!}

			@if($errors->has('phone_no'))
				<span class="help-block">
					<strong>{{ $errors->first('phone_no') }}</strong>
				</span>
			@endif
		</div>
	</div>

	<div class="form-group{{ $errors->has('status') ? 'has-error' : ''}}">
		{!! Form::label('status', trans('student.status'), ['class' => 'col-md-4 control-label']) !!}

		<div class="col-md-6">
			{!! Form::select('status', ['1'=>'Active', '2'=>'Inactive'], old('status') ? old('status') : @$student->status, ['class' => 'form-control']) !!}

			@if($errors->has('status'))
				<span class="help-block">
					<strong>{{ $errors->first('status') }}</strong>
				</span>
			@endif
		</div>
	</div>

	<div class = "form-group">
		<div class="col-sm-10 col-md-offset-2">
			<button type="submit" class="btn btn-primary"><i class="fa fa-btn fa-user">Save</i></button>
			{!! link_to_route('student.index', 'Cancel', null, array('class' => 'btn btn-danger')) !!}
		</div>
	</div>
</div>
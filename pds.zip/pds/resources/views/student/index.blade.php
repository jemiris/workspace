@extends('layouts.app')

@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					{!! trans('student.title') !!}
					{!! html_entity_decode(Html::link(route('student.create'), trans('student.add'))) !!}
				</div>
				<div class="panel-body"> 
					<table class="table table-striped table-bordered table-hover" id="view-organizations">
						<thead>
							<tr>
								<th> {!! trans('student.name') !!} </th>
								<th> {!! trans('student.class') !!} </th>
								<th> {!! trans('student.address') !!} </th>
								<th> {!! trans('student.phone_no') !!} </th>
								<th> {!! trans('student.status') !!} </th>
							</tr>
						</thead>
						<tbody>
							@foreach($student as $stud)
							<tr>
								<td>{!! Html::link(route('student.edit', $stud->id), $stud->name) !!}</td>
								<td>{!!  $stud->class !!}</td>
								<td>{!!  $stud->address !!}</td>
								<td>{!!  $stud->phone_no !!}</td>
								<td>{!!  $stud->status !!}</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
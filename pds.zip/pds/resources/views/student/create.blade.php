@extentds('layouts.app')

@section('content')
<div class="containter">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					{!! trans('student.title') !!}
				</div>
				{!! Form::open(array('route' => 'student.store', 'class' => 'form-horizontal')) !!}
				@include('student/_form')
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>
@enndsection